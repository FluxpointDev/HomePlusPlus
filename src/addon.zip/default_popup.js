document.addEventListener("DOMContentLoaded", init);

function init() {}

function AddData()
{
    console.log('Add');
}

function RemoveData()
{

}
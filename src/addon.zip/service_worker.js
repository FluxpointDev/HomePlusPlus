chrome.runtime.onInstalled.addListener(init);

function init() {}